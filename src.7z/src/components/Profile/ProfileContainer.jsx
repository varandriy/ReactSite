import React from "react";
import axios from 'axios'
import { connect } from 'react-redux';
import { setUserProfile } from '../../redux/profile-reducer';
import Profile from "./Profile";
import { withRouter } from "react-router-dom";


class ProfileContainer extends React.Component {
  componentDidMount() {
    let userId = this.props.match.params.userId //з app.js
    if(!userId){
      userId=2
    }
    axios.get(`https://social-network.samuraijs.com/api/1.0/profile/${userId}`)
      .then(response => {
        this.props.setUserProfile(response.data)
      })
    }


  render() {
    return (
      <div>
        {/* получити всі пропси і прокинути далі */}
        <Profile {...this.props} profile={this.props.profile}/>
      </div>
    );
  }
}

let mapStateToProps = (state) => ({
  profile: state.profilePage.profile //берем з редукссторе і передаєєм в презентаційну через пропси
})

let withUrlDataContainerComponent = withRouter(ProfileContainer); //для считування адресноі строки і передавання в стейт

export default connect(mapStateToProps, { setUserProfile })(withUrlDataContainerComponent);
