import React from 'react';
import preloader from '../../../assets/images/preloader.svg'

let Preloader = (props)=>{
    return   <img src={preloader}/>
  
}

export default Preloader