import React from "react";
// import s from "./Settings.module.css";

const Settings = props => {
  return <div>Settings</div>;
};

export default Settings;
